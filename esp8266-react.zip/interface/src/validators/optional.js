export default validator => value => !value || validator(value);

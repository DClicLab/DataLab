#include "DemoProject.h"
#include "TestSensor.cpp"
#include <Ticker.h>
#include <stack>
using namespace std;

//Ticker* ticks[5];
CSensor* sensorList[5];
Ticker tick1;
stack<int> queue;//Sensors needed to be pulled
char val[256];

DemoProject::DemoProject(AsyncWebServer *server, FS *fs, SecurityManager *securityManager) : AdminSettingsService(server, fs, securityManager, DEMO_SETTINGS_PATH, DEMO_SETTINGS_FILE)
{
  pinMode(BLINK_LED, OUTPUT);
  
  server->on("/val", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/plain", String(val));
  });


}


void DemoProject::start(){
  Serial.println("starting conf");

  memset(_confSensorList,0,sizeof(_confSensorList));
  struct SensorConf conftest;

  conftest.enabled=true;
  conftest.min=0;
  conftest.max=10; 
  conftest.interval=2;
  
  strcpy(conftest.name, "Test sensor");
  conftest.enabled=true;
  _confSensorList[0] = conftest;
  Serial.println("done conf");

  // init all sensors
  int i=0;
  Serial.println("reconfig");
  Serial.println("Adding test sensors");
  for (SensorConf sensorc: _confSensorList){
      Serial.println("  Adding test sensor1, interval");
      Serial.println(sensorc.interval);
      if (sensorc.interval ==0){
        Serial.println("Skipping not set");
        continue;
      }
        
      sensorList[i]= new TestSensor(sensorc.min,sensorc.max,sensorc.enabled,sensorc.interval);
      tick1.attach<int>(sensorc.interval,getValueForSensor,i);
      i++;
      //ticks[i] = new Ticker();
      //ticks[i]->attach<int>(sensorc.interval,getValueForSensor,i);

  }
  Serial.println("Done Adding test sensors");


  // do whatever is required to react to the new settings

}
void DemoProject::onConfigUpdated()
{
  reconfigureTheService();
}

void DemoProject::reconfigureTheService()
{

  Serial.println("reconfig");

  // do whatever is required to react to the new settings
}

void DemoProject::getValueForSensor(int i){
     //adding sensor to queue as we should not block in timer call
     queue.push(i);
}

DemoProject::~DemoProject() {
}

void DemoProject::loop()
{

  while (queue.size()>0)
  {
    Serial.println("getting val for sensor");
    Serial.println(queue.top());
    sprintf(val,"{\"%s\":%f}",_confSensorList[queue.top()].name,sensorList[queue.top()]->getValue());
    Serial.println(val);    
    queue.pop();
  }
  
}

void DemoProject::readFromJsonObject(JsonObject &root)
{
  _blinkSpeed = root["blink_speed"] | DEFAULT_BLINK_SPEED;
  int i = 0;
  JsonArray jsensors =  root.getMember("sensors");

  //Deserializing sensors
  for (JsonObject jsensor : jsensors)
  {
    Serial.println("adding sensor");
    Serial.println(jsensor["name"].as<char*>());

    struct SensorConf sensorConf;
    strlcpy(sensorConf.name,jsensor["name"] | "", sizeof(sensorConf.name));
    sensorConf.index = i;
    strlcpy(sensorConf.type,jsensor["type"] | "",sizeof(sensorConf.type)); 
    strlcpy(sensorConf.extra,jsensor["extra"] | "",sizeof(sensorConf.extra)); 
  }
}

void DemoProject::writeToJsonObject(JsonObject &root)
{
  // connection settings
  root["blink_speed"] = _blinkSpeed;
  root["test"] = "write";
  
}

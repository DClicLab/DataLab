#if !defined(CSensor_h)
#define CSensor_h

class CSensor
{
private:
    /* data */
public:
    //CSensor();
    CSensor(int pmin, int pmax,bool penabled, int pinterval){
        min=pmin;
        max = pmax;
        enabled = penabled;
        interval = pinterval;
    };
    //virtual void begin();
    char status[64];
    bool enabled;
    int min;
    int max;
    int interval;
    virtual float getValue();
    ~CSensor(){};
};

#endif // Sensor_h
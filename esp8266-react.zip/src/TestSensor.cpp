#if !defined(TestSensor_c)
#define TestSensor_c
#include "CSensor.h"
#include <Arduino.h>

class TestSensor : public CSensor
{
private:
    /* data */

public:
    TestSensor(int min, int max, bool enabled, int interval) : CSensor(min, max, enabled, interval){};
    void begin()
    {
        Serial.println("we are starting the sensor");
    };
    float getValue()
    {
        return random(min, max);
    };
};

#endif // TestSensor
